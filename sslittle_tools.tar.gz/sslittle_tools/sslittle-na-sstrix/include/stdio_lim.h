#define L_tmpnam 18
#define TMP_MAX 238328
#ifdef __USE_POSIX
#define L_ctermid 9
#define L_cuserid 9
#endif
#define FOPEN_MAX 64
#define FILENAME_MAX 1024
